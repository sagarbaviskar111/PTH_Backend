// routes/jobRoutes.js
const express = require('express');
const { createJob, getJobs, deleteJob } = require('../controllers/jobController');
const upload = require('../middleware/fileUpload');
const authenticateToken = require('../middleware/authMiddleware');
const { jobValidationRules } = require('../utils/validators');
const validate = require('../middleware/validate');

const router = express.Router();

// Create a new job
router.post('/', authenticateToken, upload, jobValidationRules(), validate, createJob);

// Get all jobs
router.get('/', getJobs);

// Delete a job
router.delete('/:id' ,authenticateToken, deleteJob);

module.exports = router;
