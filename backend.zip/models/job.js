const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
    company: String,
    positionName: String,
    organization: String,
    qualification: String,
    experience: String,
    salary: String,
    location: String,
    responsibilities: [String],
    qualifications: String,
    skills: [String],
    companyOverview: String,
    imageUrl: String,
    applicationLinks: [String],
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
}, { timestamps: true });

const Job = mongoose.model('Job', jobSchema);

module.exports = Job;
