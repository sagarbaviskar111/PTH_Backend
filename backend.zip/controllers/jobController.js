// controllers/jobController.js
const Job = require('../models/job');

const createJob = async (req, res) => {
    try {
        const job = new Job({
            ...req.body,
            imageUrl: req.file ? `/uploads/${req.file.filename}` : null
        });
        await job.save();
        res.status(201).json({ message: 'Job added successfully', job });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

const getJobs = async (req, res) => {
    try {
        const { id, departmentId, page = 1, limit = 10 } = req.query; // Default to page 1 and limit 10
        let jobs;

        // Convert page and limit to numbers
        const pageNumber = parseInt(page, 10);
        const limitNumber = parseInt(limit, 10);
        const skip = (pageNumber - 1) * limitNumber; // Calculate how many jobs to skip

        if (id) {
            jobs = await Job.findById(id);
            if (!jobs) return res.status(404).json({ message: 'Job not found' });
            return res.status(200).json(jobs);
        } else if (departmentId) {
            jobs = await Job.find({ department: departmentId })
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limitNumber);
        } else {
            jobs = await Job.find()
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limitNumber);
        }

        // Get the total number of jobs for pagination
        const totalJobs = await Job.countDocuments(
            id ? { _id: id } : departmentId ? { department: departmentId } : {}
        );

        // Calculate total pages
        const totalPages = Math.ceil(totalJobs / limitNumber);

        res.status(200).json({
            totalJobs,
            totalPages,
            currentPage: pageNumber,
            jobs,
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


const deleteJob = async (req, res) => {
    const { id } = req.params;

    console.log(id)

    try {
        const job = await Job.findByIdAndDelete(id);
        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }
        return res.status(200).json({ message: 'Job deleted successfully' });
    } catch (error) {
        return res.status(500).json({ message: 'Error deleting job', error: error.message });
    }
};

module.exports = { createJob, getJobs, deleteJob };
